<?php if (isset($component)) { $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackendLayout::class, []); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title', null, []); ?> Add Employee <?php $__env->endSlot(); ?>
   <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
         <div class="container-fluid">
            <div class="row mb-2">
               <div class="col-sm-6">
               </div>
               <div class="col-sm-6">
                  <ol class="breadcrumb float-sm-right">
                     <li class="breadcrumb-item"><a href="#">Home</a></li>
                     <li class="breadcrumb-item active">Add Employee </li>
                  </ol>
               </div>
            </div>
         </div>
         <!-- /.container-fluid -->
      </section>
      <form action="<?php echo e(route('admin.employee.create')); ?>" method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <!-- Main content -->
         <section class="content">
            <div class="container">
               <div class="row">
                  <!-- /.col -->
                  <div class="col-md-9">
                     <?php if(session('success')): ?>
                     <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true"><i class="fa fa-close"></i></span>
                        </button>
                     </div>
                     <?php endif; ?>
                     <?php if(session('error')): ?>
                     <div class="alert alert-danger" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true"><i class="fa fa-close"></i></span>
                        </button>
                     </div>
                     <?php endif; ?>
                     <div class="col-sm-12">
                        <!-- About Me Box -->
                        <div class="card card">
                           <div class="card-header">
                              <h3 class="card-title">General Information</h3>
                             <a class="btn btn-primary float-sm-right" href="<?php echo e(route('admin.employee')); ?>"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back to  Employees

                              </a>
                           </div>
                           <!-- /.card-header -->
                           <div class="card-body">
                              <div class="row">
                              
                             
                                 <div class="form-group col-md-4">
                                    <label>First Name <span class="text-danger">*</span></label>
                                    <input type="text" name="first_name" class="form-control" placeholder="Enter first name" value="<?php echo e(old('first_name')); ?>">
                                    <?php if($errors->has('first_name')): ?>
                                    <div class="error"><?php echo e($errors->first('first_name')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Middle Name </label>
                                    <input type="text" name="middle_name" value="<?php echo e(old('middle_name')); ?>" class="form-control" placeholder="Enter middle name">
                                    <?php if($errors->has('middle_name')): ?>
                                    <div class="error"><?php echo e($errors->first('middle_name')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Last Name <span class="text-danger">*</span></label>
                                    <input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" class="form-control" placeholder="Enter last name">
                                    <?php if($errors->has('last_name')): ?>
                                    <div class="error"><?php echo e($errors->first('last_name')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                 <div class="form-group col-md-4">
                                    <label>Alies name</label>
                                    <input type="text" name="alies_name" class="form-control" placeholder="Enter alies name" value="<?php echo e(old('alies_name')); ?>">
                                    <?php if($errors->has('alies_name')): ?>
                                    <div class="error"><?php echo e($errors->first('alies_name')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                 <div class="form-group col-md-4">
                                    <label>Email <span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control" placeholder="Enter email" value="<?php echo e(old('email')); ?>">
                                    <?php if($errors->has('email')): ?>
                                    <div class="error"><?php echo e($errors->first('email')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Gender <span class="text-danger">*</span></label>
                                    <br>
                                    <label class="radio-inline"><input type="radio" name="gender" value="male" <?php if(old('gender') == 'male'): ?>checked <?php endif; ?>> Male</label>
                                    <label class="radio-inline"><input type="radio" name="gender" value="female" <?php if(old('gender') == 'female'): ?>checked <?php endif; ?>> Female</label>
                                    <?php if($errors->has('gender')): ?>
                                    <div class="error"><?php echo e($errors->first('gender')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Marital status </label>
                                    <br>
                                    <label class="radio-inline"><input type="radio" name="marital_status" class="merried_status" value="1" <?php if(old('marital_status') == '1'): ?>checked <?php endif; ?>> Married</label>
                                    
                                    <label class="radio-inline"><input type="radio" name="marital_status" value="0" <?php if(old('marital_status') == '0'): ?>checked <?php endif; ?> class="merried_status" checked> Unmarried</label>
                                    <?php if($errors->has('marital_status')): ?>
                                    <div class="error"><?php echo e($errors->first('marital_status')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                 <div class="form-group col-md-4" id="date_of_marriage" style="display: none;">
                                    <label>Date of marriage </label>
                                    
                                     <input type="text" name="married_date" placeholder="Enter date of marriage" value="<?php echo e(old('married_date')); ?>" class="form-control"  onfocus="this.type='date'" >
                                   
                                    <?php if($errors->has('married_date')): ?>
                                    <div class="error"><?php echo e($errors->first('married_date')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                 <div class="form-group col-md-4">
                                    <label>Mobile Number </label>
                                    <input type="text" name="mobile_number" value="<?php echo e(old('mobile_number')); ?>" class="form-control" placeholder="Enter mobile number" >
                                    <?php if($errors->has('mobile_number')): ?>
                                    <div class="error"><?php echo e($errors->first('mobile_number')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Date of Joining <span class="text-danger">*</span></label>
                                    <input type="text" name="date_of_joining" 
                                    <?php if(old('date_of_joining') !=''): ?> value="<?php echo e(old('date_of_joining')); ?>" <?php else: ?> value="<?php echo e(date('d-m-Y')); ?>" <?php endif; ?> class="form-control" placeholder="Enter date of joining"  onfocus="this.type='date'">
                                    <?php if($errors->has('date_of_joining')): ?>
                                    <div class="error"><?php echo e($errors->first('date_of_joining')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                 <div class="form-group col-md-4">
                                    <label>Date of Birth </label>
                                    <input type="text" name="dob" placeholder="Enter date of birth" value="<?php echo e(old('dob')); ?>" class="form-control"   onfocus="this.type='date'">
                                    <?php if($errors->has('dob')): ?>
                                    <div class="error"><?php echo e($errors->first('dob')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                  <div class="form-group col-md-4">
                                    <label>Blood Group </label>
                                    <input type="text" name="blood_group" placeholder="Enter blood group" value="<?php echo e(old('blood_group')); ?>" class="form-control"  >
                                    <?php if($errors->has('blood_group')): ?>
                                    <div class="error"><?php echo e($errors->first('blood_group')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                 <!-- <div class="form-group col-md-4">
                                    <label>Emergency contact No </label>
                                    <input type="text" name="emergency_contact" value="<?php echo e(old('emergency_contact')); ?>" class="form-control"  placeholder="Emergency contact">
                                    <?php if($errors->has('emergency_contact')): ?>
                                    <div class="error"><?php echo e($errors->first('emergency_contact')); ?></div>
                                    <?php endif; ?>
                                 </div> -->

                                 <div class="form-group col-md-4">
                                    <label>Designation <span class="text-danger">*</span></label>
                                    <select class="form-control select2"  id="designation" name="designation">
                                       <option value="" selected>Select Designation</option>
                                       <?php if(count($role)>0): ?>
                                       <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roledata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($roledata->id); ?>" <?php if(old('designation') == $roledata->id): ?>selected <?php endif; ?>> <?php echo e($roledata->role_name); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('designation')): ?>
                                    <div class="error"><?php echo e($errors->first('designation')); ?></div>
                                    <?php endif; ?>
                                 </div>
                              </div>
                           </div>
                           <!-- /.card-body -->
                           <div class="card-footer">
                           </div>
                        </div>
                        <!-- /.card-header -->
                     </div>
                     <!-- /.card -->
                     <!--Location Address-->
                     <div class="col-sm-12">
                        <div class="card">
                           <div class="card-header">
                              <h3 class="card-title">Location/Address</h3>
                           </div>
                           <!-- /.card-header -->
                           <div class="card-body">
                              <div class="row">
                                 <div class="form-group col-md-12">
                                    <label>Countries</label>
                                    <select class="form-control select2" name="country" id="country">
                                       <option value="" selected>Select Country</option>
                                       <?php if(count($country)>0): ?>
                                       <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($countryData->name); ?>" <?php if(old('country') == $countryData->name): ?>selected <?php endif; ?>><?php echo e($countryData->name); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('country')): ?>
                                    <div class="error"><?php echo e($errors->first('country')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                <!--  <div class="form-group col-md-4">
                                    <label>State</label>
                                    <select class="form-control select2" name="state" id="state">
                                       <option value="">Select State</option>
                                       <?php if(old('state') !=''): ?>  
                                       <option value="<?php echo e(old('state')); ?>" selected><?php echo e(old('employmentType')); ?></option>
                                       <?php else: ?>
                                       <option value="" selected>Select State</option>
                                       <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('state')): ?>
                                    <div class="error"><?php echo e($errors->first('state')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>City </label>
                                    <select class="form-control select2" name="city" id="city">
                                       <option value="">Select City</option>
                                       <?php if(old('city') !=''): ?>  
                                       <option value="<?php echo e(old('city')); ?>" selected><?php echo e(old('city')); ?></option>
                                       <?php else: ?>
                                       <option value="" selected>Select City</option>
                                       <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('city')): ?>
                                    <div class="error"><?php echo e($errors->first('city')); ?></div>
                                    <?php endif; ?>
                                 </div> -->
                                 <div class="form-group col-md-6">
                                    <label>Current Address</label>
                                    <textarea class="form-control" rows="2" cols="20" name="current_address" placeholder="Enter Current Address">
                                        <?php echo e(old('current_address')); ?>

                                     </textarea>
                                    <?php if($errors->has('current_address')): ?>
                                    <div class="error"><?php echo e($errors->first('current_address')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-6">
                                    <label>Permanent Address</label>
                                    <textarea class="form-control" rows="2" cols="20" name="permanent_address" placeholder="Enter Permanent Address">
                                    <?php echo e(old('permanent_address')); ?>

                                    </textarea>
                                    <?php if($errors->has('permanent_address')): ?>
                                    <div class="error"><?php echo e($errors->first('permanent_address')); ?></div>
                                    <?php endif; ?>
                                 </div>
                              </div>
                              <!--/.row-->
                           </div>
                           <!--/.card-body-->
                        </div>
                        <!--/.card-body-->
                     </div>
                     <!--/.Location Address-->
                     <div class="col-sm-12">
                        <div class="card card">
                           <div class="card-header">
                              <h3 class="card-title">Employement Section</h3>
                           </div>
                           <!-- /.card-header -->
                           <div class="card-body">
                              <div class="row">
                                 <div class="form-group col-md-6">
                                    <label>Employment Category <span class="text-danger">*</span></label>
                                    <select class="form-control select2" name="employmentCategory" id="employmentCategory">
                                       <option value="" selected>Select Employment</option>
                                       <?php if(count($employeeCategory)>0): ?>
                                       <?php $__currentLoopData = $employeeCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empCateData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($empCateData->id); ?>" <?php if(old('employmentCategory') == $empCateData->id): ?>selected <?php endif; ?>><?php echo e($empCateData->category_name); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('employmentCategory')): ?>
                                    <div class="error"><?php echo e($errors->first('employmentCategory')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-6">
                                    <label>Employment Type <span class="text-danger">*</span></label>
                                    <select class="form-control select2" name="employmentType" id="employmentType">
                                       <?php if(old('employmentType') !=''): ?>  
                                       <option value="<?php echo e(old('employmentType')); ?>" selected><?php echo e(old('employmentType')); ?></option>
                                       <?php else: ?>
                                       <option value="" >Select Employment Type</option>
                                       <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('employmentType')): ?>
                                    <div class="error"><?php echo e($errors->first('employmentType')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                   <div class="form-group col-md-6">
                                    <label>Division </label>
                                    <select class="form-control select2" name="division">
                                       <option value="" >Select Division</option>
                                       <?php if(count($department)>0): ?>
                                       <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmentData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($departmentData->id); ?>" 
                                       <?php if(old('division')== $departmentData->id): ?> selected <?php endif; ?>>
                                       <?php echo e($departmentData->department); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('division')): ?>
                                    <div class="error"><?php echo e($errors->first('division')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                 <div class="form-group col-md-6">
                                    <label>Payroll frequency <span class="text-danger">*</span></label>
                                    <select class="form-control select2" name="payroll_frequency">
                                       <option value="" >Payroll frequency</option>
                                       <?php if(count($salaryType)>0): ?>
                                       <?php $__currentLoopData = $salaryType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salaryData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($salaryData->salary_type); ?>"  <?php if(old('salary_type')==$salaryData->salary_type): ?> selected <?php endif; ?>><?php echo e($salaryData->salary_type); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('payroll_frequency')): ?>
                                    <div class="error"><?php echo e($errors->first('payroll_frequency')); ?></div>
                                    <?php endif; ?>
                                 </div>
                               
                                 <div class="form-group col-md-6">
                                    <label>Working Type <span class="text-danger">*</span></label>
                                    <select class="form-control select2" name="working_type">
                                       <option value="" >Select Working Type</option>
                                       <option value="WFH" <?php if(old('working_type') == 'WFH'): ?>selected <?php endif; ?>>WFH</option>
                                       <option value="OFFICE" <?php if(old('working_type') == 'OFFICE'): ?>selected <?php endif; ?>>OFFICE</option>
                                       <option value="HYBRID" <?php if(old('working_type') == 'HYBRID'): ?>selected <?php endif; ?>>HYBRID</option>
                                    </select>
                                    <?php if($errors->has('working_type')): ?>
                                    <div class="error"><?php echo e($errors->first('working_type')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-6">
                                    <label>Shift Timing </label>
                                    <input type="time" name="shift_timing" class="form-control" value="<?php echo e(old('shift_timing')); ?>">
                                    <?php if($errors->has('shift_timing')): ?>
                                    <div class="error"><?php echo e($errors->first('shift_timing')); ?></div>
                                    <?php endif; ?>
                                 </div>
                              </div>
                              <!--/.row-->
                           </div>
                           <!--/.card-body-->
                        </div>
                        <!--/.card-body-->
                     </div>
                     <div class="col-sm-12">
                        <div class="card card">
                           <div class="card-header">
                              <h3 class="card-title">Assign Placement</h3>
                           </div>
                           <!-- /.card-header -->
                           <div class="card-body">
                              <div class="row">
                                 <div class="form-group col-md-4">
                                    <label>Recruiter </label>
                                    <select class="form-control select2" name="assign_recruiter" id="assign_recruiter">
                                       <option value="" >Select assign recruiter</option>
                                       <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recruiter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($recruiter->role_id == 5): ?>
                                          <option value="<?php echo e($recruiter->id); ?>" <?php if(old('assign_recruiter')==$recruiter->id): ?> selected <?php endif; ?>><?php echo e($recruiter->first_name); ?> <?php echo e($recruiter->last_name); ?></option>
                                       <?php endif; ?> 
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('assign_recruiter')): ?>
                                    <div class="error"><?php echo e($errors->first('assign_recruiter')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Recruiter Lead </label>
                                    <select class="form-control select2" name="assign_recruiter_lead" id="assign_recruiter_lead">
                                       <option value="" >Select Report to</option>
                                       <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($rl->role_id == 4): ?>
                                       <option value="<?php echo e($rl->id); ?>" <?php if(old('assign_recruiter_lead')==$rl->id): ?> selected <?php endif; ?>><?php echo e($rl->first_name); ?> <?php echo e($rl->last_name); ?></option>
                                       <?php endif; ?> 
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('assign_recruiter_lead')): ?>
                                    <div class="error"><?php echo e($errors->first('assign_recruiter_lead')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Delivery Manager </label>
                                    <select class="form-control select2" name="assign_delivery_manager" id="assign_delivery_manager">
                                       <option value="" >Select Delivery Manager</option>
                                       <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($dm->role_id == 3): ?>
                                       <option value="<?php echo e($dm->id); ?>" <?php if(old('assign_delivery_manager')==$dm->id): ?> selected <?php endif; ?>><?php echo e($dm->first_name); ?> <?php echo e($dm->last_name); ?></option>
                                       <?php endif; ?> 
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('assign_delivery_manager')): ?>
                                    <div class="error"><?php echo e($errors->first('assign_delivery_manager')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Delivery Director </label>
                                    <select class="form-control select2" name="delivery_director" id="delivery_director">
                                       <option value="" >Select Delivery Director</option>
                                       <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($dd->role_id == 14): ?>
                                             <option value="<?php echo e($dd->id); ?>" <?php if(old('delivery_director')==$dd->id): ?> selected <?php endif; ?>>
                                                <?php echo e($dd->first_name); ?> <?php echo e($dd->last_name); ?></option>
                                       <?php endif; ?> 
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('delivery_director')): ?>
                                    <div class="error"><?php echo e($errors->first('delivery_director')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>BDM </label>
                                    <select class="form-control select2" name="assign_bdm" id="assign_bdm">
                                       <option value="" >Select Assign BDM</option>
                                       <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bdm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($bdm->role_id == 7): ?>
                                       <option value="<?php echo e($bdm->id); ?>" <?php if(old('assign_bdm')==$bdm->id): ?> selected <?php endif; ?>><?php echo e($bdm->first_name); ?> <?php echo e($bdm->last_name); ?></option>
                                       <?php endif; ?> 
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('assign_bdm')): ?>
                                    <div class="error"><?php echo e($errors->first('assign_bdm')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Vice president </label>
                                    <select class="form-control select2" name="assign_vp" id="assign_vp">
                                       <option value="" >Select VP</option>
                                       <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($vp->role_id == 8): ?>
                                       <option value="<?php echo e($vp->id); ?>" <?php if(old('assign_vp')==$vp->id): ?> selected <?php endif; ?>>
                                          <?php echo e($vp->first_name); ?> <?php echo e($vp->last_name); ?></option>
                                       <?php endif; ?> 
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('assign_vp')): ?>
                                    <div class="error"><?php echo e($errors->first('assign_vp')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label> Account Manager </label>
                                    <select class="form-control select2" name="assign_account_manager" id="assign_account_manager">
                                       <option value="" >Select Account Manager</option>
                                       <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $am): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($am->role_id == 6): ?>
                                          <option value="<?php echo e($am->id); ?>" <?php if(old('assign_account_manager')==$am->id): ?> selected <?php endif; ?>><?php echo e($am->first_name); ?> <?php echo e($am->last_name); ?></option>
                                       <?php endif; ?> 
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('assign_account_manager')): ?>
                                    <div class="error"><?php echo e($errors->first('assign_account_manager')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                 <div class="form-group col-md-12" id="accout_manager_commission_type" style="display: none;" >
                                     <label> Account Manager Commission Type </label>
                                     <br>
                                    <input type="radio" name="commission_type_account_manager" id="direct_commission" value="1" checked>
                                    <label>Direct Commission </label>
                                    <input type="radio" name="commission_type_account_manager" id="indirect_commission" value="0" >
                                    <label>Indirect Commission </label>   
                                 </div>
                              </div>
                              <!--/.row-->
                           </div>
                           <!--/.card-body-->
                        </div>
                        <!--/.card-body-->
                     </div>
                     <!--/.col-sm-12-->
                     <div class="col-sm-12" id="rate_section">
                        <div class="card card">
                           <div class="card-header">
                              <h3 class="card-title">Rate</h3>
                           </div>
                           <!-- /.card-header -->
                           <div class="card-body">
                              <div class="row">
                                 <div class="form-group col-md-4">
                                    <label>VMS  </label>
                                    <select class="form-control select2"  name="vendor_cost_id" id="vms_cost">
                                       <option value="" selected>Select VMS </option>
                                       <?php if(count($VendorCost)>0): ?>
                                       <?php $__currentLoopData = $VendorCost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vcost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($vcost->id); ?>" <?php if(old('vendor_cost_id')==$vcost->id): ?> selected <?php endif; ?>><?php echo e($vcost->vms); ?> (<?php echo e($vcost->vms_cost); ?>)%</option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                    </select>
                                     <?php if($errors->has('vendor_cost_id')): ?>
                                    <div class="error"><?php echo e($errors->first('vendor_cost_id')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Bill Rate</label>
                                    <input type="text" id="bill_rate" name="bill_rate" class="form-control" value="<?php echo e(old('bill_rate')); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                    <?php if($errors->has('bill_rate')): ?>
                                    <div class="error"><?php echo e($errors->first('bill_rate')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>Gross Pay Rate</label>
                                    <input type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" id="gross_pay" name="gross_pay" class="form-control" value="<?php echo e(old('gross_pay')); ?>">
                                    <?php if($errors->has('gross_pay')): ?>
                                    <div class="error"><?php echo e($errors->first('gross_pay')); ?></div>
                                    <?php endif; ?>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label>W2 Pay Rate</label>
                                    <input type="text" id="w2_pay_rate" name="wt_payrate" class="form-control" value="<?php echo e(old('wt_payrate')); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                    <?php if($errors->has('wt_payrate')): ?>
                                    <div class="error"><?php echo e($errors->first('wt_payrate')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                 <div class="form-group col-md-4">
                                    <label>Stipend/Per Diem</label>
                                    <input type="text" id="stipend_perdiem" name="stipend_perdiem" class="form-control" value="<?php echo e(old('stipend_perdiem')); ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                    <?php if($errors->has('stipend_perdiem')): ?>
                                    <div class="error"><?php echo e($errors->first('stipend_perdiem')); ?></div>
                                    <?php endif; ?>
                                 </div>

                                

                                
                              </div>
                              <!--/.row-->
                           </div>
                           <!--/.card-body-->
                        </div>
                        <!--/.card-body-->
                     </div>
                     <!--/.col-sm-12-->
                  </div>
                  <!-- /.col -->
                  <div class="col-md-3">
                     <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                           <div class="text-center">
                              <img class="profile-user-img img-fluid img-circle" id="preview_image" src="<?php echo e(asset('images/dummy-profile.png')); ?>" alt="User profile picture">
                           </div>
                           <p class="text-muted text-center">Profile Image</p>
                           <div class="error profile_image_error"></div>
                           <div class="btn_upload">
                              <input type="file" name="profile_image" id="profile_image" accept="image/png, image/jpeg, image/gif" height="90" >
                              <a href="#" class="btn btn-primary btn-block profile-img-upload-btn"><i class="fa fa-camera" aria-hidden="true"></i> <b>Upload Image</b></a>
                           </div>
                           <a href="#" class="btn btn-danger btn-block profile-img-remove-btn" style="display: none;"><i class="fa fa-trash" aria-hidden="true"></i> <b>Remove Image</b></a>
                        </div>
                        <div class="card-footer">
                           <a href="<?php echo e(url('admin/employee/add')); ?>"  class="btn btn-danger">Cancel</a>
                           <button type="submit" class="btn btn-primary float-sm-right">Save Changes</button>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
         </section>
      </form>
      <!-- /.content -->
   </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c)): ?>
<?php $component = $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c; ?>
<?php unset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c); ?>
<?php endif; ?><?php /**PATH /home2/eyqwtvmy/public_html/hrms/resources/views/backend/employee/add.blade.php ENDPATH**/ ?>