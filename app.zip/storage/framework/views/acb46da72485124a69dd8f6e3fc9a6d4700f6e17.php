s<?php if (isset($component)) { $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackendLayout::class, []); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title', null, []); ?> Permission <?php $__env->endSlot(); ?>
   <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
         <div class="container-fluid">
            <div class="row mb-2">
               <div class="col-sm-6">
               </div>
               <div class="col-sm-6">
                  <ol class="breadcrumb float-sm-right">
                     <li class="breadcrumb-item"><a href="#">Home</a></li>
                     <li class="breadcrumb-item active">Permission </li>
                  </ol>
               </div>
            </div>
         </div>
         <!-- /.container-fluid -->
      </section>
      <!-- Main content -->
      <section class="content">
         <div class="container">
            <form action="<?php echo e(route('admin.role.insert_permission')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <div class="row">
                  <!-- /.col -->
                  <div class="col-md-12">
                     <?php if(session('success')): ?>
                     <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true"><i class="fa fa-close"></i></span>
                        </button>
                     </div>
                     <?php endif; ?>
                     <?php if(session('error')): ?>
                     <div class="alert alert-danger" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true"><i class="fa fa-close"></i></span>
                        </button>
                     </div>
                     <?php endif; ?>
                     <div class="card">
                        <!-- About Me Box -->
                        <div class="card card-primary card-outline">
                           <div class="card-header">
                              <h3 class="card-title"><?php echo e(ucwords($role->role_name)); ?> Permissions</h3>
                           </div>
                           <!-- /.card-header -->
                           <input type="hidden" name="role_id" value="<?php echo e($role->id); ?>">   
                       
                           <div class="card-body">
                              
                          
                            <div class="card-body">
                              <?php if(count($Module)>0): ?>
                                 <?php $__currentLoopData = $Module; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moduleData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                                   <?php 
                                      $permission=\App\Models\Permission::where('role_id',$role->id)
                                      ->where('module_name',$moduleData->module_name)->first();

                                   ?>
                                   <input type="hidden" name="module_name[]" value="<?php echo e($moduleData->module_name); ?>">
                                       <div class="row">
                                          <label class="col-md-3"><?php echo e($moduleData->module_name); ?></label>
                                          <div class="col-md-9">
                                             <label for="">Add</label>
                                             <input name="add[]"  type="checkbox" <?php if(@$permission->add=='1'): ?>checked <?php endif; ?> >

                                             <label for="">Edit</label>
                                             <input name="edit[]" type="checkbox" <?php if(@$permission->edit=='1'): ?>checked <?php endif; ?>  >

                                             <label for="">View</label>
                                             <input  name="list[]" type="checkbox" <?php if(@$permission->list=='1'): ?>checked <?php endif; ?> >

                                             <label for="">Delete</label>
                                             <input name="delete[]" type="checkbox" <?php if(@$permission->delete=='1'): ?>checked <?php endif; ?>  >
                                          </div>
                                       </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php endif; ?>
                           </div>
                           

                           

                           <!-- /.card-body -->
                           <div class="card-footer">
                              <button type="submit" class="btn btn-primary float-sm-right">Submit</button>
                           </div>
                        </div>
                        <!-- /.card-header -->
                     </div>
                     <!-- /.card -->
                  </div>
                  <!-- /.col -->
               </div>
               <!-- /.row -->
            </form>
         </div>
         <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
   </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c)): ?>
<?php $component = $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c; ?>
<?php unset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c); ?>
<?php endif; ?><?php /**PATH /home2/eyqwtvmy/public_html/hrms/resources/views/backend/role/permission.blade.php ENDPATH**/ ?>