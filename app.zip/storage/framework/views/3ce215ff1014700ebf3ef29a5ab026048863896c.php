<?php if (isset($component)) { $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackendLayout::class, []); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <style type="text/css">
        table thead tr th{
width: 100%;
        }

        table.dataTable th,
table.dataTable td {
  white-space: nowrap;
}
    </style>
     <?php $__env->slot('title', null, []); ?> Employees Category <?php $__env->endSlot(); ?>
    <div class="content-wrapper" style="min-height: 1518.06px;">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Category</li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>


        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true"><i class="fa fa-close"></i></span>
                </button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true"><i class="fa fa-close"></i></span>
                </button>
            </div>
        <?php endif; ?>


        <section class="content">
         
           
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">
                        Category
                    </h3>
                  <a class="btn btn-primary float-sm-right" href="<?php echo e(url('admin/category/add')); ?>"><i class="fa fa-plus"></i> Add  Category
                
                </a>
                </div>
                <div class="card-body">
                     <table class="table category table-bordered table-hover" id="category" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                               <th>Category Name</th>
                               <th>Action</th>
                            </tr>
                        </thead>
                         <tbody>

                        </tbody>
                    </table>
                </div>
                <div class="card-footer clearfix">
                </div>
            </div>
        </section>
    </div>

    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c)): ?>
<?php $component = $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c; ?>
<?php unset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c); ?>
<?php endif; ?>
<?php /**PATH /home2/eyqwtvmy/public_html/hrms/resources/views/backend/category/list.blade.php ENDPATH**/ ?>