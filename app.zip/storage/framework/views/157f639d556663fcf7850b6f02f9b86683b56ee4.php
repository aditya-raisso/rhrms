<?php if (isset($component)) { $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackendLayout::class, []); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title', null, []); ?> Commission <?php $__env->endSlot(); ?>
   <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
         <div class="container-fluid">
            <div class="row mb-2">
               <div class="col-sm-6">
               </div>
               <div class="col-sm-6">
                  <ol class="breadcrumb float-sm-right">
                     <li class="breadcrumb-item"><a href="#">Home</a></li>
                     <li class="breadcrumb-item active">Commission Criteria Edit</li>
                  </ol>
               </div>
            </div>
         </div>
         <!-- /.container-fluid -->
      </section>
      <!-- Main content -->
      <section class="content">
         <div class="container">
            <form action="<?php echo e(route('admin.commission-criteria.update')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
               <div class="row">
                  <!-- /.col -->
                  <div class="col-md-12">
                     <?php if(session('success')): ?>
                     <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true"><i class="fa fa-close"></i></span>
                        </button>
                     </div>
                     <?php endif; ?>
                     <?php if(session('error')): ?>
                     <div class="alert alert-danger" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true"><i class="fa fa-close"></i></span>
                        </button>
                     </div>
                     <?php endif; ?>

                     <div class="card">
                        <!-- About Me Box -->
                        <div class="card card-primary card-outline">
                           <div class="card-header">
                              <h3 class="card-title">Commission Edit</h3>
                              <a class="btn btn-primary float-sm-right" href="<?php echo e(url('admin/commission-criteria/list')); ?>"><i class="fa fa-eye"></i> Commissions Criteria</a>

                           </div>
                           <!-- /.card-header -->
                            <div class="card-body">
                              <div class="row">
                                  <label class="col-md-3" class="form-group" >From Net Margin</label>
                                 <div class="col-md-9">
                                       <input class="form-control" type="text" name="from_net_margin" placeholder="Enter from net margin" value="<?php echo e($data->from_net_margin); ?>">
                                       <?php if($errors->has('from_net_margin')): ?>
                                       <div class="error"><?php echo e($errors->first('from_net_margin')); ?></div>
                                       <?php endif; ?>

                                 </div>
                              </div>
                           </div>
                        
 <div class="card-body">
                         <div class="row">
                                 <label class="col-md-3" class="form-group" >To Net Margin</label>
                                 <div class="col-md-9">
                                 <input class="form-control" type="text" name="to_net_margin" placeholder="Enter  to net margin" value="<?php echo e($data->to_net_margin); ?>">
                                 <?php if($errors->has('to_net_margin')): ?>
                                 <div class="error"><?php echo e($errors->first('to_net_margin')); ?></div>
                                 <?php endif; ?>
                                 </div>
                               </div>
                    </div>

                                  <div class="card-body">
                                       <div class="row">
                                          <label class="col-md-3">Commission %</label>
                                          <div class="col-md-9">
                                              <input class="form-control" type="text" name="commission_amount" placeholder="Amount" value="<?php echo e($data->commission); ?>">
                                          </div>
                                        </div>
                                  </div>
                           <!-- /.card-body -->
                           <div class="card-footer">
                              <button type="submit" class="btn btn-primary float-sm-right">Submit</button>
                           </div>
                        </div>
                        <!-- /.card-header -->
                     </div>
                     <!-- /.card -->
                  </div>
                  <!-- /.col -->
               </div>
               <!-- /.row -->
            </form>
         </div>
         <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
   </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c)): ?>
<?php $component = $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c; ?>
<?php unset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c); ?>
<?php endif; ?><?php /**PATH /home2/eyqwtvmy/public_html/hrms/resources/views/backend/commission-criteria/edit.blade.php ENDPATH**/ ?>