<?php if (isset($component)) { $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackendLayout::class, []); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title', null, []); ?> Dashboard <?php $__env->endSlot(); ?>
   <style type="text/css">
      ul.profilebar{
      list-style: none;
      }
      ul.profilebar li{
      float: left;
      padding: 8px 18px;
      }
      ul.prf-details{
      list-style: none;
      }
      ul.prf-details li {
      float: left;
      padding: 3px 21px;
      font-weight: 600;
      }
      ul.prf-details li span{
      font-size: 14px;
      font-weight: 400;
      }
      .button-success{
      background-color: #20d45e;
      }
      a.disabled {
      pointer-events: none;
      cursor: default;
      }
   </style>
   <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
         <div class="container-fluid">
            <div class="row mb-2">
               <div class="col-sm-6">
               </div>
               <!-- /.col -->
               <div class="col-sm-6">
                  <ol class="breadcrumb float-sm-right">
                     <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>">Home</a></li>
                     <li class="breadcrumb-item active">Dashboard</li>
                  </ol>
               </div>
               <!-- /.col -->
            </div>
            <!-- /.row -->
         </div>
         <!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->
      <!-- Admin Main content -->
      <?php if(Auth::user()->role_id==1): ?>
      <section class="content">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-12">
                  <?php if(session('success')): ?>
                  <div class="alert alert-success" role="alert">
                     <?php echo e(session('success')); ?>

                     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true"><i class="fa fa-close"></i></span>
                     </button>
                  </div>
                  <?php endif; ?>
                  <?php if(session('error')): ?>
                  <div class="alert alert-danger" role="alert">
                     <?php echo e(session('error')); ?>

                     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true"><i class="fa fa-close"></i></span>
                     </button>
                  </div>
                  <?php endif; ?>
               </div>
            </div>
            <!-- Small boxes (Stat box) -->
            <div class="row">
               <div class="col-lg-4 col-6">
                  <!-- small box -->
                  <div class="small-box bg-success">
                     <div class="inner">
                        <h3><?php echo e(count($Attendance)); ?></h3>
                        <p>Today Present Employees</p>
                     </div>
                     <div class="icon">
                        <i class="fa fa-users"></i>
                     </div>
                     <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
               </div>
               <!-- ./col -->
               <div class="col-lg-4 col-6">
                  <!-- small box -->
                  <div class="small-box bg-danger">
                     <div class="inner">
                        <h3><?php echo e(count($employees)-count($Attendance)); ?></h3>
                        <p>Today Absent Employees</p>
                     </div>
                     <div class="icon">
                        <i class="fa fa-users"></i>
                     </div>
                     <a href="<?php echo e(url('employee/attendance')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
               </div>
               <!-- ./col -->
               <div class="col-lg-4 col-6">
                  <!-- small box -->
                  <div class="small-box bg-warning">
                     <div class="inner">
                        <h3><?php echo e(count($employees)); ?></h3>
                        <p>Total Employees</p>
                     </div>
                     <div class="icon">
                        <i class="icon fa fa-users"></i>
                     </div>
                     <a href="<?php echo e(url('employee/attendance')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
               </div>
               <!-- ./col -->
            </div>
            <!-- /.row -->
            <!-- Main row -->
            <!-- /.row (main row) -->
         <!--    <div class="row">
               <section class="col-lg-7 connectedSortable ui-sortable">
                  <div class="card direct-chat direct-chat-primary">
                     <div class="card-header ui-sortable-handle " style="cursor: move;">
                        <h3 class="card-title">Commission Calculater</h3>
                        
                     </div>
                     <div class="card-body">
                          <p id="total_comission"></p>
                     </div>
                     <div class="card-footer">
                        <form action="#" method="post">
                             <div class="form-group">
                              <label>Select Employee</label>
                                <select class="form-control" id="user_id" name="user">
                                 <?php if(count($employees)>0): ?>
                                 <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($empdata->id); ?>"><?php echo e($empdata->first_name); ?><?php echo e($empdata->last_name); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <?php endif; ?>
                                </select>
                              </div>
                              <div class="form-group">
                                 <label>Working Hours</label>
                              <input type="text" id="hours" name="hours" placeholder="Enter net working hours" class="form-control">
                              </div>

                              <button class="btn btn-primary" type="button" id="Calculater">Submit</button>

                              
                          
                        </form>
                     </div>
                  </div>
               </section>
               <section class="col-lg-5 connectedSortable ui-sortable"></section>
            </div> -->
         </div>
         <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
      <?php endif; ?>
      <?php if(Auth::user()->role_id !=1): ?>
      <section class="content">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-12">
                  <?php if(session('success')): ?>
                  <div class="alert alert-success" role="alert">
                     <?php echo e(session('success')); ?>

                     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true"><i class="fa fa-close"></i></span>
                     </button>
                  </div>
                  <?php endif; ?>
                  <?php if(session('error')): ?>
                  <div class="alert alert-danger" role="alert">
                     <?php echo e(session('error')); ?>

                     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true"><i class="fa fa-close"></i></span>
                     </button>
                  </div>
                  <?php endif; ?>
               </div>
            </div>
            <div class="row">
               <div class="col-md-3">
                  <div class="card card-primary card-outline">
                     <div class="card-body box-profile">
                        <div class="text-center">
            
                           <?php if(!empty(Auth::user()->avatar)): ?>
                           <img class="profile-user-img img-fluid img-circle" id="preview_image" src="<?php echo e(url('storage/app/user/'.Auth::user()->avatar)); ?>" height="90" alt="User profile picture">
                           <?php else: ?>
                           <img class="profile-user-img img-fluid img-circle" id="preview_image" src="<?php echo e(asset('images/dummy-profile.png')); ?>" height="90" alt="User profile picture">
                           <?php endif; ?>
                        </div>
                        <h3 class="profile-username text-center"><?php echo e(ucwords(Auth::user()->first_name)); ?> <?php echo e(ucwords(Auth::user()->middle_name)); ?> <?php echo e(ucwords(Auth::user()->last_name)); ?></h3>
                        <p class="text-muted text-center"><?php echo e(Auth::user()->designation); ?></p>
                     </div>
                  </div>
               </div>
               <div class="col-md-9">
                  <?php
                  $attendence= \App\Models\Attendance::where('user_id',Auth::user()->id)->whereDate('punch_in',date('Y-m-d'))->first();
                  $punch_in= $attendence->punch_in ?? 0;
                  $punch_out=$attendence->punch_out ?? 0; 
                  $user_id=Crypt::encryptString(Auth::user()->id);
                  ?>
                  <div class="card">
                     <div class="col-sm-12">
                        <ul class="profilebar">
                           <li><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e(Auth::user()->city ?? '-'); ?></li>
                           <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e(Auth::user()->email ?? '-'); ?></li>
                           <li><i class="fa fa-phone"></i> <?php echo e(Auth::user()->mobile_number ?? '-'); ?></li>
                           <li><a <?php if(!empty($punch_in)): ?> class="btn btn-block btn-default disabled" href="#" <?php else: ?> class="btn btn-success"   <?php endif; ?> href="<?php echo e(route('employee.attendance.punch-in')); ?>"> <i class="fa fa-sign-in" aria-hidden="true" ></i> Punch In</a></li>
                           <li><a  <?php if(empty($punch_out) && !empty($punch_in)): ?> href="<?php echo e(route('employee.attendance.punch-out')); ?>" class="btn btn-success" <?php else: ?> class="btn btn-block btn-default disabled"  href="#"  <?php endif; ?>  ><i class="fa fa-sign-out" aria-hidden="true"></i> Punch Out</a></li>
                        </ul>
                     </div>
                     <hr>
                     <div class="col-sm-12">
                        <ul class="prf-details">
                           <li>EMPLOYEE NUMBER <br><span><?php echo e(Auth::user()->emp_id); ?></span></li>
                           <li>JOB TITLE  <br><span><?php echo e(Auth::user()->designation); ?></span></li>
                           <li>DEPARTMENT  <br><span><?php echo e(Auth::user()->department); ?></span></li>
                           <li>REPORT TO  <br><span><?php echo e(Auth::user()->reportTo->first_name ?? ''); ?> <?php echo e(Auth::user()->reportTo->last_name ?? ''); ?></span></li>
                        </ul>
                     </div>
                     <div class="card-header p-2">
                        <ul class="nav nav-pills">
                           <li class="nav-item"><a class="nav-link active" href="#activity" data-toggle="tab">ABOUT</a></li>
                           <li class="nav-item"><a class="nav-link" href="<?php echo e(route('employee.edit',['emp'=>$user_id])); ?>">PROFILE</a></li>
                           <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">JOB</a></li>
                           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('employee/document/add')); ?>">DOCUMENTS</a></li>
                           <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">JOB</a></li>
                           <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">ASSETS</a></li>
                        </ul>
                     </div>
                     <div class="card-body">
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-6">
                  <div class="card card">
                     <div class="card-header">
                        <h3 class="card-title">Professional Summery</h3>
                     </div>
                     <div class="card-body">
                        <?php echo e(Auth::user()->professional_summery); ?>

                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="card card">
                     <div class="card-header">
                        <h3 class="card-title">Skills</h3>
                     </div>
                     <div class="card-body">
                        <?php echo e(Auth::user()->skills); ?>

                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="card card">
                     <div class="card-header">
                        <h3 class="card-title">Contact Details</h3>
                     </div>
                     <div class="card-body">
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="card card">
                     <div class="card-header">
                        <h3 class="card-title">Experience</h3>
                     </div>
                     <div class="card-body">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <?php endif; ?>
      <!-- //Admin Main content -->
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c)): ?>
<?php $component = $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c; ?>
<?php unset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c); ?>
<?php endif; ?><?php /**PATH /home2/eyqwtvmy/public_html/hrms/resources/views/backend/dashboard.blade.php ENDPATH**/ ?>