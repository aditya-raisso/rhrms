<?php if (isset($component)) { $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackendLayout::class, []); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title', null, []); ?> Category <?php $__env->endSlot(); ?>
  
   <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
         <div class="container-fluid">
            <div class="row mb-2">
               <div class="col-sm-6">
               </div>
               <div class="col-sm-6">
                  <ol class="breadcrumb float-sm-right">
                     <li class="breadcrumb-item"><a href="#">Home</a></li>
                     <li class="breadcrumb-item active">Category </li>
                  </ol>
               </div>
            </div>
         </div>
         <!-- /.container-fluid -->
      </section>
      <!-- Main content -->
      <section class="content">
         <div class="container">
            <form action="<?php echo e(route('admin.category.create')); ?>" method="post" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
            <div class="row">
                
              
               <!-- /.col -->
               <div class="col-md-12">
                  <?php if(session('success')): ?>
                  <div class="alert alert-success" role="alert">
                     <?php echo e(session('success')); ?>

                     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true"><i class="fa fa-close"></i></span>
                     </button>
                  </div>
                  <?php endif; ?>
                  <?php if(session('error')): ?>
                  <div class="alert alert-danger" role="alert">
                     <?php echo e(session('error')); ?>

                     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true"><i class="fa fa-close"></i></span>
                     </button>
                  </div>
                  <?php endif; ?>
                 
                     <div class="card">
                        <!-- About Me Box -->
                        <div class="card card">
                           <div class="card-header">
                              <h3 class="card-title">Add Category </h3>
                              <a class="btn btn-primary float-sm-right" href="<?php echo e(url('admin/category')); ?>"><i class="fa fa-eye"></i> Categories
                              </a>
                           </div>
                           <!-- /.card-header -->
                           <div class="card-body">
                              <div class="row">
                                  <div class="col-md-12 form-group">
                                     <label>Category Name</label>
                                     <input type="text" name="category_name" class="form-control" placeholder="Category Name">
                                     <?php if($errors->has('category_name')): ?>
                                    <div class="error"><?php echo e($errors->first('category_name')); ?></div>
                                    <?php endif; ?>
                                  </div>

                                  <div class="col-md-12 form-group">
                                     <label>Is Parent</label>
                                     <select name="is_parient" class="form-control">
                                        <option value="">Select Is Parent Category</option>
                                        <?php if(count($data)>0): ?>
                                           <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->category_name); ?></option>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                     </select>
                                        <?php if($errors->has('is_parient')): ?>
                                    <div class="error"><?php echo e($errors->first('is_parient')); ?></div>
                                    <?php endif; ?>
                                  </div>
                              </div>
                           </div>
                           <!-- /.card-body -->
                           <div class="card-footer">
                              <button type="submit" class="btn btn-primary float-sm-right">Submit</button>
                           </div>
                        </div>
                        <!-- /.card-header -->
                     </div>
                  
                  <!-- /.card -->
               </div>
               <!-- /.col -->
            </div>
            
            <!-- /.row -->
         </form>
         </div>

         <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
   </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c)): ?>
<?php $component = $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c; ?>
<?php unset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c); ?>
<?php endif; ?><?php /**PATH /home2/eyqwtvmy/public_html/hrms/resources/views/backend/category/add.blade.php ENDPATH**/ ?>