<?php if (isset($component)) { $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackendLayout::class, []); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('title', null, []); ?> Admin Profile <?php $__env->endSlot(); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
           
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
              <li class="breadcrumb-item active">Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">

   
            <div class="card  card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="<?php echo e(asset('images/admin-icon.png')); ?>"
                       alt="Admin profile picture">
                </div>

                <h3 class="profile-username text-center"><?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?></h3>
                <p class="text-muted text-center"><?php echo e($data->email); ?></p>
              </div>
            
            </div>
         </div>
          <!-- /.col -->
          <div class="col-md-8">
             <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true"><i class="fa fa-close"></i></span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true"><i class="fa fa-close"></i></span>
                        </button>
                    </div>
                <?php endif; ?>
            <form action="<?php echo e(route('admin.profile.update')); ?>" method="post">
              <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
              <?php echo csrf_field(); ?>
           
            <div class="card">
                 <!-- About Me Box -->
            <div class="card ">
              <div class="card-header">
                <h3 class="card-title">Profile Update</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
               <div class="row">
                 <div class="form-group col-md-6">
                   <label>First Name</label>
                   <input type="text" name="first_name" class="form-control" placeholder="Enter first name" value="<?php echo e($data->first_name); ?>">
                   <?php if($errors->has('first_name')): ?>
                <div class="error"><?php echo e($errors->first('first_name')); ?></div>
                <?php endif; ?>
                 </div>

                 <div class="form-group col-md-6">
                   <label>Last Name</label>
                   <input type="text" name="last_name" class="form-control" placeholder="Enter last name" value="<?php echo e($data->last_name); ?>">
                    <?php if($errors->has('last_name')): ?>
                <div class="error"><?php echo e($errors->first('last_name')); ?></div>
                <?php endif; ?>
                 </div>

                 <div class="form-group col-md-6">
                   <label>Email</label>
                   <input type="text" readonly name="email" class="form-control" placeholder="Enter email" value="<?php echo e($data->email); ?>">
                   <input type="hidden" name="old_email" value="<?php echo e($data->email); ?>">
                   <?php if($errors->has('email')): ?>
                <div class="error"><?php echo e($errors->first('email')); ?></div>
                <?php endif; ?>
                 </div>

                 <div class="form-group col-md-6">
                   <label>Password</label>
                   <input type="text" name="password" class="form-control" placeholder="Enter password" value="">
                    <?php if($errors->has('password')): ?>
                       <div class="error"><?php echo e($errors->first('password')); ?></div>
                    <?php endif; ?>
                 </div>
                
                 
               </div>
              </div>
              <!-- /.card-body -->
               <div class="card-footer">
                 <button type="submit" class="btn btn-primary float-sm-right">Submit</button>
              </div>

            </div>
              <!-- /.card-header -->
             
            </div>
          </form>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
     
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c)): ?>
<?php $component = $__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c; ?>
<?php unset($__componentOriginal85df81faa239d0aedc3b7cea8afff61c2b96e34c); ?>
<?php endif; ?>
<?php /**PATH /home2/eyqwtvmy/public_html/hrms/resources/views/backend/profile.blade.php ENDPATH**/ ?>