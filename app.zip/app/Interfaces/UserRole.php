<?php
namespace App\Interfaces;
 interface UserRole{
	const Admin = 1;
	const  DeliveryManager= 3;
	const  RecruiterLead=4;
	const Recruiter = 5;
	const AccountManager = 6;
	const BDM = 7;
	const VP = 8;
	const House = 9;
	const HRManager = 10;
	const  Consultant= 11;
	const  ITExecutive= 12;
	const  SoftwareDeveloper= 13;
	const  DeliveryDirector= 14;
}

?>